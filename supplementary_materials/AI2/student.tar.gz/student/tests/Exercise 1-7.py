OK_FORMAT = True

test = {   'name': 'Exercise 1-7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> q17_eig_vals.shape\n(3,)', 'failure_message': '次元数は3である必要があります / The dimension should be 3', 'hidden': False, 'locked': False},
                                   {'code': '>>> q17_eig_vecs.shape\n(3, 3)', 'failure_message': '次元数は3*3である必要があります / The dimension should be 3*3', 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert sorted(q17_eig_vals) == [-2.0, 1.0, 3.0]\n',
                                       'failure_message': '固有値は -2, 1, 3 の3つになっている必要があります / The eigenvalues must be -2, 1, 3',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> for _, (val, vec) in enumerate(zip(q17_eig_vals, q17_eig_vecs.T)):\n...     np.testing.assert_allclose(q17_diagX @ vec, val * vec)\n',
                                       'failure_message': '各固有値と固有ベクトルが対応していません / The eigenvalues do not correspond to the eigenvectors',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
