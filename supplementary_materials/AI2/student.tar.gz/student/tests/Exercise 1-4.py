OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> q14_X.shape\n(2, 4)', 'failure_message': '次元が異なっています', 'hidden': False, 'locked': False},
                                   {'code': '>>> q14_X.shape\n(2, 4)', 'failure_message': 'The dimensions are different.', 'hidden': False, 'locked': False},
                                   {'code': '>>> q14_Y.shape\n(4, 3)', 'failure_message': '次元が異なっています', 'hidden': False, 'locked': False},
                                   {'code': '>>> q14_Y.shape\n(4, 3)', 'failure_message': 'The dimensions are different.', 'hidden': False, 'locked': False},
                                   {'code': '>>> q14_XY.shape\n(2, 3)', 'failure_message': '次元が異なっています', 'hidden': False, 'locked': False},
                                   {'code': '>>> q14_XY.shape\n(2, 3)', 'failure_message': 'The dimensions are different.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
