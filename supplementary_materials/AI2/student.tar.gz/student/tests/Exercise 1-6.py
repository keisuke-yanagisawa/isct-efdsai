OK_FORMAT = True

test = {   'name': 'Exercise 1-6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> inv_inv_q16_A.shape == q16_A.shape\nTrue', 'failure_message': '3*3次元である必要があります', 'hidden': False, 'locked': False},
                                   {'code': '>>> inv_inv_q16_A.shape == q16_A.shape\nTrue', 'failure_message': 'It should be a 3*3 dimension', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(inv_inv_q16_A, q16_A)\nTrue', 'failure_message': '逆行列の逆行列が元の行列と一致しません。', 'hidden': False, 'locked': False},
                                   {   'code': '>>> np.allclose(inv_inv_q16_A, q16_A)\nTrue',
                                       'failure_message': 'The inverse of the inverse matrix does not match the original matrix.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
