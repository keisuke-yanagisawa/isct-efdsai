OK_FORMAT = True

test = {   'name': 'Exercise 2-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> len(q22_labels) == len(q21_X)\nTrue',
                                       'failure_message': 'クラスタリング結果の要素数が正しくありません。q21_Xのクラスタリングを行い、len(q22_labels) と len(q21_X) が等しいことを確認してください。 / The number of elements in the clustering result is '
                                                          'incorrect. Perform clustering on q21_X and ensure len(q22_labels) equals len(q21_X).',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.unique(q22_labels).shape[0] == 2 and q22_labels.max() == 1 and (q22_labels.min() == 0)\nnp.True_',
                                       'failure_message': '2つのクラスタに分類されていることを確認してください。 / Ensure that the points are classified into 2 clusters.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.all(q22_labels == np.array([1, 1, 1, 1, 1, 0, 0, 0, 0])) or np.all(q22_labels == np.array([0, 0, 0, 0, 0, 1, 1, 1, 1]))\nnp.True_',
                                       'failure_message': 'クラスタリング結果が誤っています。異なるクラスタリング手法や異なるデータを使っていないか確認してください。 / The clustering result is incorrect. Check if you are using different clustering '
                                                          'methods or different data.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
