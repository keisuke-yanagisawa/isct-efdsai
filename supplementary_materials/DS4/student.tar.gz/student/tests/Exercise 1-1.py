OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(clustering, AgglomerativeClustering)\nTrue',
                                       'failure_message': 'AgglomerativeClustering を利用してください。あるいは、変数名が間違っている可能性があります。 / Please use AgglomerativeClustering. Alternatively, the variable name may be '
                                                          'incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> from sklearn.utils.validation import check_is_fitted\n>>> check_is_fitted(clustering)\n',
                                       'failure_message': 'clustering.fit()を実行してください。 / Please execute clustering.fit().',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(q11_labels) == len(q1_sample)\nTrue',
                                       'failure_message': 'クラスタリング結果の要素数が正しくありません。q1_sampleのクラスタリングを行い、len(q11_labels) と len(q1_sample) が等しいことを確認してください。 / The number of elements in the clustering '
                                                          'result is incorrect. Perform clustering on q1_sample and ensure len(q11_labels) equals len(q1_sample).',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.all(q11_labels == np.array([0, 0, 1, 0, 0, 1, 0, 0, 1]))\nnp.True_',
                                       'failure_message': 'クラスタリング結果が誤っています。異なるクラスタリング手法や異なるデータを使っていないか確認してください。 / The clustering result is incorrect. Check if you are using different clustering '
                                                          'methods or different data.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
