OK_FORMAT = True

test = {   'name': 'Exercise 2-1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert q21_X.shape[1] == 2\n', 'failure_message': '2次元空間上の点を設定してください。 / Please set points in 2D space.', 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert q21_X.shape[0] == q21_labels.shape[0]\n',
                                       'failure_message': 'q21_X と q21_labels の要素数が一致していません。データ数とラベル数が一致していることを確認してください。 / The number of elements in q21_X and q21_labels do not match. Please ensure '
                                                          'the number of data points matches the number of labels.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
