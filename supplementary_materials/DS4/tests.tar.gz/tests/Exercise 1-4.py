OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert q14_dist_matrix.shape == (9, 9)\n',
                                       'failure_message': '距離行列の要素数が正しくありません。距離行列の要素数が正しいことを確認してください。 / The number of elements in the distance matrix is incorrect. Please verify that the number of '
                                                          'elements in the distance matrix is correct.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.isclose(q14_dist_matrix, np.array([[0.0, 0.29990167, 0.20020999, 0.28051576, 0.09968029, 0.1006243, 0.49484984, 0.44064667, 0.28911008], '
                                               '[0.29990167, 0.0, 0.500101, 0.22190998, 0.20032247, 0.40041998, 0.39500032, 0.40664033, 0.54180208], [0.20020999, 0.500101, 0.0, 0.44667775, '
                                               '0.29980667, 0.09974513, 0.63750777, 0.56180535, 0.20600087], [0.28051576, 0.22190998, 0.44667775, 0.0, 0.22454623, 0.36183427, 0.22079196, 0.19600041, '
                                               '0.5695834], [0.09968029, 0.20032247, 0.29980667, 0.22454623, 0.0, 0.2001025, 0.44533587, 0.40932761, 0.36312004], [0.1006243, 0.40041998, 0.09974513, '
                                               '0.36183427, 0.2001025, 0.0, 0.56490797, 0.49828109, 0.22642679], [0.49484984, 0.39500032, 0.63750777, 0.22079196, 0.44533587, 0.56490797, 0.0, '
                                               '0.10010499, 0.78269026], [0.44064667, 0.40664033, 0.56180535, 0.19600041, 0.40932761, 0.49828109, 0.10010499, 0.0, 0.72199793], [0.28911008, '
                                               '0.54180208, 0.20600087, 0.5695834, 0.36312004, 0.22642679, 0.78269026, 0.72199793, 0.0]]), atol=1e-08).all()\n',
                                       'failure_message': '距離行列が正しくありません。距離行列の計算方法を確認してください。 / The distance matrix is incorrect. Please check the method of distance matrix calculation.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(q14_nearest_indices) == 9\nTrue',
                                       'failure_message': '最近傍インデックスの要素数が正しくありません。最近傍インデックスの要素数が正しいことを確認してください。 / The number of nearest indices is incorrect. Please verify that the number of nearest '
                                                          'indices is correct.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.all((0 <= q14_nearest_indices) & (q14_nearest_indices < len(q1_sample)))\n',
                                       'failure_message': '最近傍インデックスが正しくありません。最近傍インデックスが正しいことを確認してください。 / The nearest indices are incorrect. Please verify that the nearest indices are correct.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.all(q14_nearest_indices == np.array([0, 1, 2, 3, 4, 5, 6, 7, 8]))\n',
                                       'failure_message': '最近傍インデックスが正しくありません。最近傍インデックスが正しいことを確認してください。 / The nearest indices are incorrect. Please verify that the nearest indices are correct.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
