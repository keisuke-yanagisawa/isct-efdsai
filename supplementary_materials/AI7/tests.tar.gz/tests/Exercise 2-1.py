OK_FORMAT = True

test = {   'name': 'Exercise 2-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert q21_partial[0].in_channels == 1\n',
                                       'failure_message': 'digitsデータはモノクロデータであり、チャネル数は1です。 / The digits data is grayscale, and the number of channels should be 1.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> sample_input = torch.zeros((1, 1, 8, 8))\n>>> assert q21_partial(sample_input) is not None\n',
                                       'failure_message': 'エラーを発生せずに出力されている必要があります。 / There should be no errors when outputting.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
