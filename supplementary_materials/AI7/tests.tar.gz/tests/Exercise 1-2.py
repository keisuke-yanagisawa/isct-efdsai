OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.random.seed(seed=42)\n>>> f = np.random.rand(1, 1)\n>>> p = 2\n>>> assert isinstance(padding(f, p), np.ndarray)\n',
                                       'failure_message': 'numpy.ndarrayになっている必要があります / It must be a numpy.ndarray',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(seed=42)\n'
                                               '>>> f = np.random.rand(1, 1)\n'
                                               '>>> p = 2\n'
                                               '>>> np.testing.assert_array_almost_equal(padding(f, p), np.array([[0, 0, 0], [0, f[0, 0], 0], [0, 0, 0]]))\n',
                                       'failure_message': 'f.shape = (1,1), p = 2の場合が適切な出力になりませんでした。p = 2の場合、入力の周囲を囲むように0を追加する必要があります。 / The output was not correct for f.shape = (1,1), p = 2. It '
                                                          'should add 0s around the input.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(seed=42)\n'
                                               '>>> f = np.random.rand(3, 3)\n'
                                               '>>> p = 2\n'
                                               '>>> np.testing.assert_array_almost_equal(padding(f, p), np.array([[0, 0, 0, 0, 0], [0, f[0, 0], f[0, 1], f[0, 2], 0], [0, f[1, 0], f[1, 1], f[1, 2], '
                                               '0], [0, f[2, 0], f[2, 1], f[2, 2], 0], [0, 0, 0, 0, 0]]))\n',
                                       'failure_message': 'f.shape = (3,3), p = 2の場合が適切な出力になりませんでした。p = 2の場合、入力の周囲を囲むように0を追加する必要があります。 / The output was not correct for f.shape = (3,3), p = 2. It '
                                                          'should add 0s around the input.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.random.seed(seed=42)\n'
                                               '>>> f = np.random.rand(4, 2)\n'
                                               '>>> p = 2\n'
                                               '>>> np.testing.assert_array_almost_equal(padding(f, p), np.array([[0, 0, 0, 0], [0, f[0, 0], f[0, 1], 0], [0, f[1, 0], f[1, 1], 0], [0, f[2, 0], f[2, '
                                               '1], 0], [0, f[3, 0], f[3, 1], 0], [0, 0, 0, 0]]))\n',
                                       'failure_message': 'f.shape = (4,2), p = 2の場合が適切な出力になりませんでした。正方行列以外が入力されることは想定された実装になっていますか？ / The output was not correct for f.shape = (4,2), p = 2. Is your '
                                                          'implementation supposed to handle non-square matrices?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
