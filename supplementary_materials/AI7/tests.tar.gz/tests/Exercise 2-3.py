OK_FORMAT = True

test = {   'name': 'Exercise 2-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q23_loss_fn, torch.nn.modules.loss.CrossEntropyLoss)\n',
                                       'failure_message': 'Loss関数として交差エントロピー誤差を用いている必要があります。 / The loss function must be cross-entropy loss.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> params_in_optimizer = set((id(p) for group in q23_optimizer.param_groups for p in group['params']))\n"
                                               '>>> assert all((id(p) in params_in_optimizer for p in q22_cnn.parameters()))\n',
                                       'failure_message': '全てのq22_cnnのパラメータが存在している必要があります。 / All parameters of q22_cnn must be present.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> val_accuracy = evaluate_model(q23_trained_model, q23_loss_fn, q2_val_loader)[1]\n>>> assert val_accuracy > 0.9\n',
                                       'failure_message': '正解率が0.9以上である必要があります。 / The accuracy must be 0.9 or higher.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
