OK_FORMAT = True

test = {   'name': 'Exercise 2-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> q24_test_loss_otter, q24_test_accuracy_otter = evaluate_model(q23_trained_model, q23_loss_fn, q2_test_loader)\n'
                                               '>>> assert q24_test_accuracy_otter == q24_test_accuracy\n',
                                       'failure_message': 'テストデータに対する予測正解率は evaluate_model() を用いて計算してください。 / The prediction accuracy for the test data must be calculated using evaluate_model().',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
