OK_FORMAT = True

test = {   'name': 'Exercise 2-5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q25_loss_fn, torch.nn.modules.loss.CrossEntropyLoss)\n',
                                       'failure_message': '損失関数としてCrossEntropyLossが用いられている必要があります。 / The loss function must be cross-entropy loss.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> q25_trained_model.state_dict()['1.weight'][1][:5]\ntensor([ 0.0686, -0.1034, -0.4436, -0.1783, -1.0650])",
                                       'failure_message': "モデルの重みの更新が想定通りに行われていません。q25_slpのパラメータはoptimizerに設定しましたか？ / The model's weights must have been updated as expected. Did you set the "
                                                          'parameters of q25_slp in the optimizer?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> q25_test_accuracy\n0.9583333333333334',
                                       'failure_message': 'テストデータに対する予測正解率は evaluate_model() を用いて計算してください。なお、q25_test_accuracyの値は0.958程度になるはずです。 / The prediction accuracy for the test data must be '
                                                          'calculated using evaluate_model(). The value of q25_test_accuracy should be around 0.958.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
