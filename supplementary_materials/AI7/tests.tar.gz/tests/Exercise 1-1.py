OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> f, g = (np.random.rand(4, 4), np.random.rand(2, 2))\n>>> assert isinstance(conv(f, g), np.ndarray)\n',
                                       'failure_message': 'numpy.ndarrayになっている必要があります。 / It must be a numpy.ndarray.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import scipy\n'
                                               '>>> np.random.seed(seed=42)\n'
                                               '>>> f, g = (np.random.rand(1, 1), np.random.rand(1, 1))\n'
                                               ">>> np.testing.assert_array_almost_equal(conv(f, g), scipy.signal.correlate2d(f, g, mode='valid'))\n",
                                       'failure_message': 'f,gが1*1行列の時に正常に動く必要がありますseed=42の時array([[0.35608065]]) / It should work correctly when f and g are 1*1 matrices. Expected output with '
                                                          'seed=42 is array([[0.35608065]])',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import scipy\n'
                                               '>>> np.random.seed(seed=42)\n'
                                               '>>> f, g = (np.random.rand(2, 2), np.random.rand(2, 2))\n'
                                               ">>> np.testing.assert_array_almost_equal(conv(f, g), scipy.signal.correlate2d(f, g, mode='valid'))\n",
                                       'failure_message': 'f,gが2*2行列の時に正常に動く必要がありますseed=42の時array([[0.76780201]]) / It should work correctly when f and g are 2*2 matrices. Expected output with '
                                                          'seed=42 is array([[0.76780201]])',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import scipy\n'
                                               '>>> np.random.seed(seed=42)\n'
                                               '>>> f, g = (np.random.rand(3, 3), np.random.rand(2, 2))\n'
                                               ">>> np.testing.assert_array_almost_equal(conv(f, g), scipy.signal.correlate2d(f, g, mode='valid'))\n",
                                       'failure_message': '3×3行列と2×2行列の畳み込みの結果が誤っています。計算結果は2×2の行列になっていますか？ / The result of convolving a 3×3 matrix with a 2×2 matrix is incorrect. Is the result a 2×2 '
                                                          'matrix?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import scipy\n'
                                               '>>> np.random.seed(seed=42)\n'
                                               '>>> f, g = (np.random.rand(5, 3), np.random.rand(2, 2))\n'
                                               ">>> np.testing.assert_array_almost_equal(conv(f, g), scipy.signal.correlate2d(f, g, mode='valid'))\n",
                                       'failure_message': '5×3行列と2×2行列の畳み込みの結果が誤っています。正方行列以外が入力される場合が想定された実装になっていますか？ / The result of convolving a 5×3 matrix with a 2×2 matrix is incorrect. Is the '
                                                          'implementation designed to handle inputs that are not square matrices?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
