OK_FORMAT = True

test = {   'name': 'Exercise 2-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> q21_dt_d5.get_params()['max_depth'] == 5\nTrue",
                                       'failure_message': 'max_depthが5ではありません．正しく設定しましたか？ / The max_depth is not 5. Did you set it correctly?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(q21_gen_perf_score, np.array([0.90350877, 0.93859649, 0.92105263, 0.93859649, 0.90265487]).mean(), atol=1e-06)\nnp.True_',
                                       'failure_message': 'q21_gen_perf_scoreが正しくありません．正しく学習できていますか？ / q21_gen_perf_score is incorrect. Have the models been learned correctly?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
