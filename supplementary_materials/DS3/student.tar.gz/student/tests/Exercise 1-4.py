OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> from sklearn.utils.validation import check_is_fitted\n>>> check_is_fitted(q4_dt)\n',
                                       'failure_message': 'q4_dtがfitされていません．正しく学習できていますか？ / q4_dt is not fitted. Have the models been learned correctly?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(q4_accuracy, 0.9, atol=1e-05)\nnp.False_',
                                       'failure_message': 'q4_accuracyが正しくありません．正しく学習できていますか？ / q4_accuracy is incorrect. Have the models been learned correctly?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
