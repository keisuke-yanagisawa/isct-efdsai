OK_FORMAT = True

test = {   'name': 'Exercise 2-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> q22_dt.get_params()['min_impurity_decrease'] == 0.1\nTrue",
                                       'failure_message': 'min_impurity_decreaseが0.1ではありません．正しく設定しましたか？ / min_impurity_decrease is not 0.1. Did you set it correctly?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(q22_gen_perf_score, np.array([0.87719298, 0.90350877, 0.92105263, 0.90350877, 0.91150442]).mean(), atol=1e-06)\nnp.True_',
                                       'failure_message': "q22_dt_otherのcross_val_score() が想定通りでない、random_stateが59以外に設定されている可能性があります / q22_dt_other's cross_val_score() is not as expected; the "
                                                          'random_state may be set to something other than 59',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
