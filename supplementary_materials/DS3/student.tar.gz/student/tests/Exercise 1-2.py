OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> q2_y_pred is not None\nTrue',
                                       'failure_message': 'y_pred に値が代入されていません．正しく設定しましたか？ / No value has been assigned to y_pred. Did you set it correctly?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.all(q2_y_pred == [1, 1])\nnp.True_',
                                       'failure_message': 'y_pred の中身が正しくありません．正しく学習できていますか？ / The contents of y_pred are incorrect. Have you learned correctly?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
