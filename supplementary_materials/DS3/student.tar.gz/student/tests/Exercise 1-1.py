OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> q1_dt.get_params()['max_depth'] != None\nTrue",
                                       'failure_message': 'max_depthが"None"です．正しく設定しましたか？ / The max_depth value is "None". Did you set it?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> q1_dt.get_params()['max_depth'] == 5\nTrue",
                                       'failure_message': 'max_depthが5ではありません．正しく設定しましたか？ / The max_depth value is not five. Did you set it?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
