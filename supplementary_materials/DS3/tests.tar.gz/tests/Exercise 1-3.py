OK_FORMAT = True

test = {   'name': 'Exercise 1-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert np.isclose(q3_accuracy, 0.8, atol=1e-05)\n',
                                       'failure_message': 'accuracy が 0.8 になっていません．モデルを正しく学習できていますか？ / Accuracy is not 0.8. Have the models been learned correctly?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
