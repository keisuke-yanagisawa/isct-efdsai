OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> assert q1_dt.get_params()['max_depth'] != None\n",
                                       'failure_message': 'max_depthが"None"です．正しく設定しましたか？ / The max_depth value is "None". Did you set it?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert q1_dt.get_params()['max_depth'] == 5\n",
                                       'failure_message': 'max_depthが5ではありません．正しく設定しましたか？ / The max_depth value is not five. Did you set it?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
