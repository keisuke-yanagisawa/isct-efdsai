OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> from sklearn.utils.validation import check_is_fitted\n>>> check_is_fitted(q4_dt)\n',
                                       'failure_message': 'q4_dtがfitされていません．正しく学習できていますか？ / q4_dt is not fitted. Have the models been learned correctly?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> ans_dt = DecisionTreeClassifier().fit(X_train, y_train)\n'
                                               '>>> ans_y_pred = ans_dt.predict(X_test)\n'
                                               '>>> ans_accuracy = accuracy_score(y_test, ans_y_pred)\n'
                                               '>>> assert np.isclose(q4_accuracy, ans_accuracy, atol=1e-05)\n',
                                       'failure_message': 'q4_accuracyが正しくありません．正しく学習できていますか？ / q4_accuracy is incorrect. Have the models been learned correctly?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
