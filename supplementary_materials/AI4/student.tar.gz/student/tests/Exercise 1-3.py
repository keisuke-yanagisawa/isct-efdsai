OK_FORMAT = True

test = {   'name': 'Exercise 1-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert q13_pred is not Ellipsis\n',
                                       'failure_message': '解答を記述してから自動添削システムを実行してください。 / Write your solution and try again.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert q13_pred.shape == (3,)\n', 'failure_message': '3つの予測結果が返されるはずです。 / Three predictions should be returned.', 'hidden': False, 'locked': False},
                                   {   'code': '>>> import numpy as np\n>>> assert np.allclose(q13_pred, [1.0, -1.0, -1.0])\n',
                                       'failure_message': '予測結果が誤っています。 / The predicted values are incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
