OK_FORMAT = True

test = {   'name': 'Exercise 2-2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> q22_y.shape == (40,)\nTrue', 'failure_message': 'q22_y の長さは 40 であるべきです。 / The length of q22_y should be 40.', 'hidden': False, 'locked': False},
                                   {   'code': '>>> np.testing.assert_almost_equal(q22_y[0], 0, decimal=4)\n'
                                               '>>> np.testing.assert_almost_equal(q22_y[10], -0.346574, decimal=4)\n'
                                               '>>> np.testing.assert_almost_equal(q22_y[20], -0.366204, decimal=4)\n'
                                               '>>> np.testing.assert_almost_equal(q22_y[24], -0.359934, decimal=4)\n'
                                               '>>> np.testing.assert_almost_equal(q22_y[30], -0.346574, decimal=4)\n',
                                       'failure_message': 'q22_y の値が誤っています。 / The values of q22_y are incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
