OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.testing.assert_almost_equal(q14_lr.intercept_, 0.0)\n',
                                       'failure_message': 'fit_intercept = False であるべきです。 / fit_intercept = False  should be set.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.allclose(q14_lr.coef_, [[-1.26677905, -0.78171987]], rtol=0.0001)\nFalse',
                                       'failure_message': '重み$w$は[[-1.26677905 -0.78171987]]であるべきです。 / The weights $w$ should be [[-1.26677905 -0.78171987]].',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
