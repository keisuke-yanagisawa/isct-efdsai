OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> q12_pred_proba.shape\n(3, 2)', 'failure_message': 'The shape of q412_pred_proba should be (3, 2).', 'hidden': False, 'locked': False},
                                   {   'code': '>>> np.allclose(q12_pred_proba, [[0.01668595, 0.98331405], [0.41864908, 0.58135092], [0.68413691, 0.31586309]], rtol=0.0001)\nFalse',
                                       'failure_message': 'The predicted probability is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
