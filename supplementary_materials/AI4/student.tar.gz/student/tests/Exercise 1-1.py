OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> q11_pred_proba is not Ellipsis\nTrue', 'failure_message': 'Write your solution and try again.', 'hidden': False, 'locked': False},
                                   {'code': '>>> q11_pred_proba.shape\n(1, 2)', 'failure_message': 'The shape of q11_pred_proba should be (1, 2).', 'hidden': False, 'locked': False},
                                   {   'code': '>>> np.allclose(q11_pred_proba, [[0.000287867405, 0.999712133]], rtol=0.0001)\nFalse',
                                       'failure_message': 'The predicted probability is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
