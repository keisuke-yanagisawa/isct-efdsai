OK_FORMAT = True

test = {   'name': 'Exercise 2-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import math\n>>> np.testing.assert_almost_equal(q24_optimize(), math.e, decimal=2)\n',
                                       'failure_message': 'q24_optimize() は 2.717 に収束するべきです。 / q24_optimize() should converge to 2.717.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
