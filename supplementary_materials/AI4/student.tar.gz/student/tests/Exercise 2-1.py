OK_FORMAT = True

test = {   'name': 'Exercise 2-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.testing.assert_almost_equal(q21_f(1.0), 0.0)\n',
                                       'failure_message': 'q21_f(1.0) = 0 であるべきです。（なお、表示は -0.0 などとなる可能性があります） / q21_f(1.0) should equal 0 (Note - it may display as -0.0).',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_almost_equal(q21_f(5.0), -0.32188758, decimal=3)\n',
                                       'failure_message': 'q21_f(5.0) = -0.32188758... であるべきです。 / q21_f(5.0) should equal -0.32188758...',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
