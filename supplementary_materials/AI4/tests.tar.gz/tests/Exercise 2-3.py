OK_FORMAT = True

test = {   'name': 'Exercise 2-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.testing.assert_almost_equal(q23_derivative(1.0), -1.0)\n',
                                       'failure_message': 'q23_derivative(1.0) = -1.0 であるべきです。 / q23_derivative(1.0) should equal -1.0.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_almost_equal(q23_derivative(2.7), 0.0, decimal=3)\n',
                                       'failure_message': 'q23_derivative(2.7) = -0.0009 であるべきです。 / q23_derivative(2.7) should equal -0.0009.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
