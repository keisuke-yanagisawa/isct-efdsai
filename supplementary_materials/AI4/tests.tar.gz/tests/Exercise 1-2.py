OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.testing.assert_array_equal(q12_pred_proba.shape, (3, 2))\n',
                                       'failure_message': 'The shape of q412_pred_proba should be (3, 2).',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> ans_lr = LogisticRegression(fit_intercept=False).fit(X_train, y_train)\n'
                                               '>>> ans_pred_proba = ans_lr.predict_proba(X_q12)\n'
                                               '>>> np.testing.assert_array_almost_equal(q12_pred_proba, ans_pred_proba, decimal=4)\n',
                                       'failure_message': 'The predicted probability is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
