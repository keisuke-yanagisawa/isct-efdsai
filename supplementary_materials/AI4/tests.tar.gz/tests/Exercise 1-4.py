OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.testing.assert_almost_equal(q14_lr.intercept_, 0.0)\n',
                                       'failure_message': 'fit_intercept = False であるべきです。 / fit_intercept = False  should be set.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> ans_lr = LogisticRegression(fit_intercept=False).fit(q14_X_train, q14_y_train)\n'
                                               '>>> np.testing.assert_array_almost_equal(q14_lr.coef_, ans_lr.coef_, decimal=4)\n',
                                       'failure_message': '重み$w$は[[-1.26677905 -0.78171987]]であるべきです。 / The weights $w$ should be [[-1.26677905 -0.78171987]].',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
