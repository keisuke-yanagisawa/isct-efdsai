OK_FORMAT = True

test = {   'name': 'Exercise 1-8',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q18_loss_fn, torch.nn.CrossEntropyLoss)\n',
                                       'failure_message': 'q18_loss_fnが交差エントロピー誤差ではありません / q18_loss_fn is not the cross-entropy loss',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert isinstance(q18_optimizer, torch.optim.SGD)\n',
                                       'failure_message': 'q18_optimizerがSGDではありません / q18_optimizer is not SGD',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert all((p1 is p2 for p1, p2 in zip(q18_nn.parameters(), q18_optimizer.param_groups[0]['params'])))\n",
                                       'failure_message': "q18_nnのパラメータが登録されていません / q18_nn's parameters are not registered",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert q18_optimizer.param_groups[0]['lr'] == 0.05\n",
                                       'failure_message': "q18_optimizer の学習率が0.05ではありません / q18_optimizer's learning rate is not 0.05",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> _ = torch.manual_seed(0)\n'
                                               '>>> ans_nn = torch.nn.Sequential(torch.nn.Linear(8 * 8, 32), torch.nn.ReLU(), torch.nn.Dropout(0.5), torch.nn.Linear(32, 10))\n'
                                               '>>> ans_loss_fn = torch.nn.CrossEntropyLoss()\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_nn.parameters(), lr=0.05)\n'
                                               '>>> _ = torch.manual_seed(0)\n'
                                               '>>> ans_train = train(ans_nn, ans_loss_fn, ans_optimizer, train_loader, val_loader, verbose=False)\n'
                                               '>>> torch.testing.assert_close(q18_train[0].weight, ans_train[0].weight)\n',
                                       'failure_message': "モデルの訓練が想定通りに動作していません。 / The model's training did not work as expected.",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n'
                                               '>>> _ = torch.manual_seed(0)\n'
                                               '>>> ans_nn = torch.nn.Sequential(torch.nn.Linear(8 * 8, 32), torch.nn.ReLU(), torch.nn.Dropout(0.5), torch.nn.Linear(32, 10))\n'
                                               '>>> ans_loss_fn = torch.nn.CrossEntropyLoss()\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_nn.parameters(), lr=0.05)\n'
                                               '>>> _ = torch.manual_seed(0)\n'
                                               '>>> ans_train = train(ans_nn, ans_loss_fn, ans_optimizer, train_loader, val_loader, verbose=False)\n'
                                               '>>> _, ans_test_acc = evaluate_model(ans_train, ans_loss_fn, test_loader)\n'
                                               '>>> np.testing.assert_almost_equal(q18_test_acc, ans_test_acc)\n',
                                       'failure_message': 'テストデータの正解率が誤っています。 / The accuracy on the test data is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
