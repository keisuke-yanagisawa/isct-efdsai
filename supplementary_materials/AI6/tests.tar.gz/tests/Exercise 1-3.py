OK_FORMAT = True

test = {   'name': 'Exercise 1-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_slp = torch.nn.Sequential(torch.nn.Linear(8 * 8, 10))\n'
                                               '>>> ans_loss_fn = torch.nn.CrossEntropyLoss()\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_slp.parameters(), lr=0.02)\n'
                                               '>>> ans_trained_model = train(ans_slp, ans_loss_fn, ans_optimizer, train_loader, val_loader, epoch=15, verbose=False)\n'
                                               '>>> ans_loss, ans_acc = evaluate_model(ans_trained_model, ans_loss_fn, test_loader)\n'
                                               '>>> torch.testing.assert_close(q13_loss, ans_loss)\n',
                                       'failure_message': '平均損失が誤っています。学習はできていますか？ / The average loss is incorrect. Is the model trained properly?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_slp = torch.nn.Sequential(torch.nn.Linear(8 * 8, 10))\n'
                                               '>>> ans_loss_fn = torch.nn.CrossEntropyLoss()\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_slp.parameters(), lr=0.02)\n'
                                               '>>> ans_trained_model = train(ans_slp, ans_loss_fn, ans_optimizer, train_loader, val_loader, epoch=15, verbose=False)\n'
                                               '>>> ans_loss, ans_acc = evaluate_model(ans_trained_model, ans_loss_fn, test_loader)\n'
                                               '>>> torch.testing.assert_close(q13_acc, ans_acc)\n',
                                       'failure_message': '正解率が誤っています。学習はできていますか？ / The accuracy is incorrect. Is the model trained properly?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
