OK_FORMAT = True

test = {   'name': 'Exercise 1-5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q15_mlp[0], torch.nn.Linear)\n'
                                               '>>> assert isinstance(q15_mlp[2], torch.nn.Linear)\n'
                                               '>>> assert isinstance(q15_mlp, torch.nn.Sequential)\n',
                                       'failure_message': 'q15_mlp は２つの Linearレイヤーを持つSequentialである必要があります。 / q15_mlp must have two Linear layers in a Sequential.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert isinstance(q15_mlp[1], torch.nn.Sigmoid)\n',
                                       'failure_message': 'q15_mlpの二層めはSigmoidである必要があります。 / The second layer of q15_mlp must be Sigmoid.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> params = list(q15_mlp.parameters())\n'
                                               ">>> for param, opt_param in zip(params, q15_optimizer.param_groups[0]['params']):\n"
                                               '...     assert param is opt_param\n',
                                       'failure_message': 'Optimizerに登録されているモデルがq15_mlpのものではないようです。 / The model registered in the optimizer does not seem to be that of q15_mlp.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
