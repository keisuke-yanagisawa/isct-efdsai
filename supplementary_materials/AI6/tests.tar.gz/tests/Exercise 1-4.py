OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> torch.testing.assert_close(q14_X_test, q14_X_test_copy)\n',
                                       'failure_message': 'q14_X_testがかわってしまっています。 / q14_X_test must remain unchanged.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n'
                                               '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_slp = torch.nn.Sequential(torch.nn.Linear(8 * 8, 10))\n'
                                               '>>> ans_loss_fn = torch.nn.CrossEntropyLoss()\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_slp.parameters(), lr=0.02)\n'
                                               '>>> ans_trained_model = train(ans_slp, ans_loss_fn, ans_optimizer, train_loader, val_loader, epoch=15, verbose=False)\n'
                                               '>>> ans_y_pred = predict_proba(ans_trained_model, q14_X_test)\n'
                                               '>>> ans_max_num = np.argmax(ans_y_pred)\n'
                                               '>>> ans_max_prob = ans_y_pred[0][ans_max_num]\n'
                                               '>>> assert q14_max_num == ans_max_num\n',
                                       'failure_message': '予測確率最大の数字が誤っています。 / The predicted class with the highest probability is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n'
                                               '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_slp = torch.nn.Sequential(torch.nn.Linear(8 * 8, 10))\n'
                                               '>>> ans_loss_fn = torch.nn.CrossEntropyLoss()\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_slp.parameters(), lr=0.02)\n'
                                               '>>> ans_trained_model = train(ans_slp, ans_loss_fn, ans_optimizer, train_loader, val_loader, epoch=15, verbose=False)\n'
                                               '>>> ans_y_pred = predict_proba(ans_trained_model, q14_X_test)\n'
                                               '>>> ans_max_num = np.argmax(ans_y_pred)\n'
                                               '>>> ans_max_prob = ans_y_pred[0][ans_max_num]\n'
                                               '>>> torch.testing.assert_close(ans_max_prob, q14_max_prob)\n',
                                       'failure_message': '予測確率が誤っています。 / The predicted probability is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
