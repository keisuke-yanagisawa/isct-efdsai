OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import numpy as np\n>>> assert np.allclose(q11_y_pred, (0.0, 0.0, 0.1, 0.5, 0.0, 0.2, 0.0, 0.1, 0.1, 0.0))\n',
                                       'failure_message': 'q11_y_predが変わっていない必要があります。 / q11_y_pred must remain unchanged.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> assert q11_y_true == 3\n', 'failure_message': 'q11_y_true が変わっていない必要があります / q11_y_true must remain unchanged', 'hidden': False, 'locked': False},
                                   {   'code': '>>> torch.testing.assert_close(q11_loss, torch.tensor(1.9146), rtol=0.0001, atol=0.0001)\n',
                                       'failure_message': '1.9146になっている必要があります。 / It should be 1.9146.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
