OK_FORMAT = True

test = {   'name': 'Exercise 1-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'{q13_loss:.6f}')\n0.179351\n",
                                       'failure_message': 'q13_loss=0.179...である必要があります / q13_loss should be 0.179...',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> q13_acc\n0.9555555555555556', 'failure_message': 'q13_acc=0.955...である必要があります / q13_acc should be 0.955...', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
