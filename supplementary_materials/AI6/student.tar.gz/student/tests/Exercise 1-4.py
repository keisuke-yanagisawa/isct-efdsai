OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> torch.allclose(q14_X_test, q14_X_test_copy)\nTrue',
                                       'failure_message': 'q14_X_testがかわってしまっています。 / q14_X_test must remain unchanged.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> q14_max_num == 6\nTrue', 'failure_message': 'saidaikaするクラスは６である必要があります。 / The predicted class should be 6.', 'hidden': False, 'locked': False},
                                   {   'code': '>>> q14_max_prob\ntensor(0.9814)',
                                       'failure_message': '最大化する確率は0.9814であることを確認して下さい / The maximum probability should be 0.9814.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
