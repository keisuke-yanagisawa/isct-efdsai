OK_FORMAT = True

test = {   'name': 'Exercise 1-7',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> q17_in.size()\ntorch.Size([2, 5])',
                                       'failure_message': 'q17_inの形が誤っています。 shapeは(2, 5)である必要があります。 / The shape of q17_in is incorrect. The shape should be (2, 5).',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> q17_in[q17_out == 0.0] = 0.0\n>>> assert torch.allclose(q17_in * 2, q17_out, atol=1e-06)\n',
                                       'failure_message': 'q17_inの一部の値が0になり、かつ値が2倍になっている必要があります。 / Some values of q17_in should be 0 and others should be doubled.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
