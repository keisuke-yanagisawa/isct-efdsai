OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> len(q11_pc1_score) == 100\nTrue',
                                       'failure_message': 'q11_pc1_score の要素数が異なります。PCAへの入力形式が誤っていませんか？ / The number of elements in q11_pc1_score is different. Is the input format for PCA incorrect?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n'
                                               '>>> np.isclose(np.mean(q11_pc1_score), 0, atol=1e-05) and np.isclose(np.var(q11_pc1_score), 0.8292292718, atol=1e-05)\n'
                                               'np.True_',
                                       'failure_message': 'q11_pc1_score の値が異なっています。元のデータ q1_X の値を取得していませんか？ / The values of q11_pc1_score are different. Are you getting the values of the original '
                                                          'data q1_X?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
