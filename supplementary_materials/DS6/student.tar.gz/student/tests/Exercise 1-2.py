OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> len(q12_pc1_score) == 100\nTrue',
                                       'failure_message': 'q12_pc1_score の要素数が異なります。SpectralEmbeddingへの入力形式が誤っていませんか？誤って q12 ではなく q11 の変数を更新していませんか？ / The number of elements in q12_pc1_score is '
                                                          'different. Is the input format for SpectralEmbedding incorrect? Did you accidentally update the variable q11 instead of q12?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n'
                                               '>>> np.isclose(np.mean(q12_pc1_score), 2.569711e-05, atol=1e-05) and np.isclose(np.var(q12_pc1_score), 0.00110877, atol=1e-05)\n'
                                               'np.True_',
                                       'failure_message': 'q12_pc1_score の値が異なっています。元のデータ q1_X の値を取得していませんか？誤って q12 ではなく q11 の変数を更新していませんか？ / The values of q12_pc1_score are different. Are you '
                                                          'obtaining values from the original data q1_X? Did you accidentally update the variable q11 instead of q12?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
