OK_FORMAT = True

test = {   'name': 'Exercise 2-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert 0 < q23_avg_dist_unpaired\n'
                                               '>>> assert q23_avg_dist_unpaired < 10\n'
                                               '>>> assert np.isclose(q23_avg_dist_unpaired, 1.9183889222883153, atol=1e-05)\n',
                                       'failure_message': 'q23_avg_dist_unpaired が適切ではありません。距離の計算が誤っていませんか？ / q23_avg_dist_unpaired is not appropriate. Is the distance calculation incorrect?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert q23_avg_dist_unpaired < 100000.0\n',
                                       'failure_message': 'q23_avg_dist_unpaired に平均値ではなく合計値が記録されています。サンプル数で割って平均値を求めてください。 / q23_avg_dist_unpaired records a sum instead of an average. Please divide '
                                                          'by the number of samples to get the average.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
