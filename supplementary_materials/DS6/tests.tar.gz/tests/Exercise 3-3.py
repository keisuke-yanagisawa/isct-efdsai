OK_FORMAT = True

test = {   'name': 'Exercise 3-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert np.issubdtype(type(q33_best_digit), np.integer)\n',
                                       'failure_message': 'q33_best_digit が整数値になっていません。平均値ではなく、最もcos類似度が高い数字はどれか？を q33_best_digit に代入してください。 / q33_best_digit is not an integer. Please assign the '
                                                          'digit with the highest cosine similarity to q33_best_digit instead of an average.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert not isinstance(q33_best_digit, str)\n',
                                       'failure_message': 'q33_best_digit が文字列になっています。整数値を入力するようにしてください。 / q33_best_digit is a string. Please input an integer value.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert 0 <= q33_best_digit <= 9\n',
                                       'failure_message': 'q33_best_digit が0以上9以下の整数値ではありません。 / q33_best_digit is not an integer between 0 and 9.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert q33_best_digit == 0\n',
                                       'failure_message': 'q33_best_digit が誤っています。全ての数字について平均cos類似度を出力するなどして値を確認してみてください。 / q33_best_digit is incorrect. Please check the values by outputting the '
                                                          'average cosine similarities for all digits.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
