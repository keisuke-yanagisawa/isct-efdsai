OK_FORMAT = True

test = {   'name': 'Exercise 2-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert 0 < q22_avg_dist_paired < 10 and np.isclose(q22_avg_dist_paired, 0.4204476307692026, atol=1e-05)\n',
                                       'failure_message': 'q22_avg_dist_paired が適切ではありません。距離の計算が誤っていませんか？ / q22_avg_dist_paired is not appropriate. Is the distance calculation incorrect?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert q22_avg_dist_paired < 100\n',
                                       'failure_message': 'q22_avg_dist_paired に平均値ではなく合計値が記録されています。サンプル数で割って平均値を求めてください。 / q22_avg_dist_paired records a sum instead of an average. Please divide by '
                                                          'the number of samples to get the average.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
