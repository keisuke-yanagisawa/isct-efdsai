OK_FORMAT = True

test = {   'name': 'Exercise 3-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert np.issubdtype(type(q32_avg_cos_similarity), np.floating)\n',
                                       'failure_message': 'q32_avg_cos_similarity が実数値ではない値になっています。 / q32_avg_cos_similarity is not a real number.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.isclose(q32_avg_cos_similarity, 0.9015666194103865, atol=1e-05)\n',
                                       'failure_message': 'q32_avg_cos_similarity の値が誤っています。 / The value of q32_avg_cos_similarity is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert 0 < q32_avg_cos_similarity and q32_avg_cos_similarity < 1\n',
                                       'failure_message': 'q32_avg_cos_similarity に平均値ではなく合計値が記録されています。サンプル数で割って平均値を求めてください。 / q32_avg_cos_similarity records a sum instead of an average. Please '
                                                          'divide by the number of samples to get the average.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
