OK_FORMAT = True

test = {   'name': 'Exercise 2-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q22_is_orthogonal(np.array([1, 0]), np.array([0, 1])), np.bool_) or isinstance(q22_is_orthogonal(np.array([1, 0]), np.array([0, '
                                               '1])), bool)\n',
                                       'failure_message': 'q22_is_orthogonal() の返り値が真偽値型ではありません。return 文は書きましたか？ / The return value of q22_is_orthogonal() is not a boolean. Did you write the return '
                                                          'statement?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert q22_is_orthogonal(np.array([1, 0]), np.array([0, 1])) == True\n',
                                       'failure_message': 'q22_is_orthogonal([1, 0], [0, 1]) の返り値が True になっていません。 / The return value of q22_is_orthogonal([1, 0], [0, 1]) is not True.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert q22_is_orthogonal(np.array([1, 0]), np.array([1, 0])) == False\n',
                                       'failure_message': 'is_orthogonal([1, 0], [1, 0]) の返り値が False になっていません。 / The return value of q22_is_orthogonal([1, 0], [1, 0]) is not False.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> from sklearn.decomposition import PCA\n'
                                               '>>> q22_pca = PCA(n_components=2).fit(q21_X)\n'
                                               '>>> assert q22_is_orthogonal(q22_pca.components_[0], q22_pca.components_[1])\n',
                                       'failure_message': 'pca.components_ が直交していないと判定されています。 / It is determined that pca.components_ are not orthogonal.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
