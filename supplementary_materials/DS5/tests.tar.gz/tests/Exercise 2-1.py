OK_FORMAT = True

test = {   'name': 'Exercise 2-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> from sklearn.utils.validation import check_is_fitted\n>>> check_is_fitted(q21_pca)\n',
                                       'failure_message': 'q21_pca.fit() が実行されていません。 / q21_pca.fit() has not been executed.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.isclose(q21_pc1_ratio, 0.14890593593061524, rtol=1e-05)\n',
                                       'failure_message': 'q21_pc1_ratio の値が正しくありません。 / The value of q21_pc1_ratio is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
