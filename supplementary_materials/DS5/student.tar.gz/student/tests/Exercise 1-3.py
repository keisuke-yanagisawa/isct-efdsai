OK_FORMAT = True

test = {   'name': 'Exercise 1-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.isclose(q13_x10_average, 10.382303839732888, atol=1e-06)\nnp.True_',
                                       'failure_message': 'q13_x10_average の値が正しくありません。 / The value of q13_x10_average is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
