OK_FORMAT = True

test = {   'name': 'Exercise 2-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(q23_pc1_score, (int, float))\nTrue',
                                       'failure_message': '主成分得点はスカラー値であり、ベクトルではありません。 / The principal component score should be a scalar, not a vector.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(q23_pc1_score, np.dot(q21_X[42], q21_pca.components_[0]))\nnp.True_',
                                       'failure_message': '値が誤っています。内積は np.dot(v1, v2) で求めることができます。 / The value is incorrect. The dot product can be calculated with np.dot(v1, v2).',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
