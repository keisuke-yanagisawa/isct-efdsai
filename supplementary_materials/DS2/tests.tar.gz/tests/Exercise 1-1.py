OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.testing.assert_almost_equal(q11_mean_small, 4.0, decimal=6)\n',
                                       'failure_message': 'q11_mean_small の値が間違っています。q1_df_small の中身を表示してみると、平均値は4.0でありそうなことがわかります。 / The value of q11_mean_small is incorrect. Display the contents '
                                                          'of q1_df_small to see that the mean is likely 4.0.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_almost_equal(q11_max_large, 0.999, decimal=6)\n',
                                       'failure_message': 'q11_max_large の値が間違っています。一旦for文などを用いて値を確認してみましょう。 / The value of q11_max_large is incorrect. Try using a `for` loop to manually verify the '
                                                          'values.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
