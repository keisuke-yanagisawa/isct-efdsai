OK_FORMAT = True

test = {   'name': 'Exercise 2-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert 0.4 <= q21_sample_mean and q21_sample_mean <= 0.6\n',
                                       'failure_message': 'q21_sample_mean の値が 0.4 から 0.6 に収まっていません。 / The value of q21_sample_mean is not between 0.4 and 0.6.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
