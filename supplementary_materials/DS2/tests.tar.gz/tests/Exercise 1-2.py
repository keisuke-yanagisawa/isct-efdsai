OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q12_count_small, pd.Series)\n',
                                       'failure_message': 'q12_count_small の変数の型は、pd.Series である必要があります。 / The type of q12_count_small should be pd.Series.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert q12_count_small.column_A.item() == 2 and q12_count_small.column_B.item() == 2 and (q12_count_small.column_C.item() == 2) and '
                                               '(q12_count_small.column_D.item() == 2)\n',
                                       'failure_message': 'q12_count_small の値が誤っています。q1_df_small の中身を表示してみると、column_B の値が4より大きい行は2行であるようです。 / The value of q12_count_small is incorrect. Displaying '
                                                          'the contents of q1_df_small shows that there are 2 rows where column_B has values greater than 4.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_equal(len(q12_partial_df_large), 500)\n',
                                       'failure_message': 'q12_partial_df_large の行数が誤っています。 / The row count of q12_partial_df_large is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert q12_partial_df_large['d'].max() < 0\n",
                                       'failure_message': 'q12_partial_df_large の d 列の最大値が0より小さい値になっていません。 / The maximum value in column `d` of q12_partial_df_large is not less than 0.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> assert q12_partial_df_large['d'].max() < 0\n", 'hidden': False, 'locked': False},
                                   {   'code': '>>> np.testing.assert_almost_equal(q12_partial_df_large.shape, (500, 4), decimal=6)\n'
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['a'].mean(), -0.501, decimal=6)\n"
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['b'].mean(), -0.5005, decimal=6)\n"
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['c'].mean(), -0.5, decimal=6)\n"
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['d'].mean(), -0.4995, decimal=6)\n"
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['a'].var(), 0.0835, decimal=6)\n"
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['b'].var(), 0.0835, decimal=6)\n"
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['c'].var(), 0.0835, decimal=6)\n"
                                               ">>> np.testing.assert_almost_equal(q12_partial_df_large['d'].var(), 0.0835, decimal=6)\n",
                                       'failure_message': 'q12_partial_df_large の中身が誤っています。 / The contents of q12_partial_df_large are incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
