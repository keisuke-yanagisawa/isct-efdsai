OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(q12_count_small, pd.Series)\nTrue',
                                       'failure_message': 'q12_count_small の変数の型は、pd.Series である必要があります。 / The type of q12_count_small should be pd.Series.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> q12_count_small.column_A.item() == 2 and q12_count_small.column_B.item() == 2 and (q12_count_small.column_C.item() == 2) and '
                                               '(q12_count_small.column_D.item() == 2)\n'
                                               'True',
                                       'failure_message': 'q12_count_small の値が誤っています。q1_df_small の中身を表示してみると、column_B の値が4より大きい行は2行であるようです。 / The value of q12_count_small is incorrect. Displaying '
                                                          'the contents of q1_df_small shows that there are 2 rows where column_B has values greater than 4.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> len(q12_partial_df_large) == 500\nTrue',
                                       'failure_message': 'q12_partial_df_large の行数が誤っています。 / The row count of q12_partial_df_large is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> q12_partial_df_large['d'].max() < 0\nnp.True_",
                                       'failure_message': 'q12_partial_df_large の d 列の最大値が0より小さい値になっていません。 / The maximum value in column `d` of q12_partial_df_large is not less than 0.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> q12_partial_df_large['d'].max() < 0\nnp.True_", 'hidden': False, 'locked': False},
                                   {   'code': ">>> np.isclose(q12_partial_df_large['a'].mean(), -0.501, atol=1e-06) and np.isclose(q12_partial_df_large['b'].mean(), -0.5005, atol=1e-06) and "
                                               "np.isclose(q12_partial_df_large['c'].mean(), -0.5, atol=1e-06) and np.isclose(q12_partial_df_large['d'].mean(), -0.4995, atol=1e-06) and "
                                               "np.isclose(q12_partial_df_large['a'].var(), 0.0835, atol=1e-06) and np.isclose(q12_partial_df_large['b'].var(), 0.0835, atol=1e-06) and "
                                               "np.isclose(q12_partial_df_large['c'].var(), 0.0835, atol=1e-06) and np.isclose(q12_partial_df_large['d'].var(), 0.0835, atol=1e-06)\n"
                                               'np.True_',
                                       'failure_message': 'q12_partial_df_large の中身が誤っています。 / The contents of q12_partial_df_large are incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
