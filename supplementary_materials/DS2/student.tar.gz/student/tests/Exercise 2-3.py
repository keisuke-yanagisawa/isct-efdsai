OK_FORMAT = True

test = {   'name': 'Exercise 2-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.isclose(q23_estimated_mean, 0.714, atol=1e-06)\nnp.True_',
                                       'failure_message': '母平均は標本平均を使って推定することができます。 / Population mean can be estimated using the sample mean.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(q23_estimated_var, 0.17123, atol=1e-06)\nnp.True_',
                                       'failure_message': '母分散は不偏分散を使って推定することができます。 / Population variance can be estimated using the unbiased sample variance.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
