OK_FORMAT = True

test = {   'name': 'Exercise 2-5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> q25_is_rejected == False\nnp.True_',
                                       'failure_message': 'この問題では、帰無仮説は棄却できません。 / In this question, the null hypothesis cannot be rejected.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(q25_tvalue, -0.99, atol=0.0001)\nnp.True_',
                                       'failure_message': 't検定を行うと、t値が計算されます。t値の計算式を確認してください。 / Conducting a t-test produces a t-value. Verify the formula for calculating the t-value.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
