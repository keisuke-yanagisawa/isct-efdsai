OK_FORMAT = True

test = {   'name': 'Exercise 2-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import random\n'
                                               '>>> __q23_sample1 = random.sample(range(100), 10)\n'
                                               '>>> np.isclose(estimate_pop_mean(__q23_sample1), statistics.mean(__q23_sample1), atol=1e-06)\n'
                                               'np.True_',
                                       'failure_message': '母平均は標本平均を使って推定することができます。 / Population mean can be estimated using the sample mean.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import random\n'
                                               '>>> __q23_sample2 = random.sample(range(100), 10)\n'
                                               '>>> np.isclose(estimate_pop_var(__q23_sample2), statistics.variance(__q23_sample2), atol=1e-06)\n'
                                               'np.True_',
                                       'failure_message': '母分散は不偏分散を使って推定することができます。不偏分散の計算式に注意してください。 / Population variance can be estimated using the unbiased sample variance. Pay attention to the '
                                                          'formula for unbiased variance.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
