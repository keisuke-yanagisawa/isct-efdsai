OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert q11_sampled_X.shape[0] == 2\n',
                                       'failure_message': 'q11_sampled_X のサンプル数が正しくありません。 / The number of samples in q11_sampled_X is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.all(q11_sampled_X == np.array([2, 3]))\n',
                                       'failure_message': 'q11_sampled_X の値が誤っています。復元抽出をおこなっていますか？np.random.seed(42)は最初に実行されていますか？ / The values of q11_sampled_X are incorrect. Are you performing '
                                                          'resampling? Has np.random.seed(42) been run first?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
