OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert q12_sampled_X.shape == (5, 3)\n',
                                       'failure_message': 'q12_sampled_X のサンプル数が正しくありません。 / The number of samples in q12_sampled_X is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert q12_sampled_y.shape[0] == 5\n',
                                       'failure_message': 'q12_sampled_y のサンプル数が正しくありません。 / The number of samples in q12_sampled_y is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> boolean = True\n'
                                               '>>> for col in range(q12_sampled_X.shape[0]):\n'
                                               '...     __match_index = np.all(q1_X == q12_sampled_X[col], axis=1)\n'
                                               '...     boolean = boolean == __match_index.any()\n'
                                               '...     __ind = np.where(__match_index)\n'
                                               '...     __ytest = (q1_y[__ind] == q12_sampled_y[col]).any()\n'
                                               '...     boolean = boolean == __ytest\n'
                                               '>>> assert boolean\n',
                                       'failure_message': 'q12_sampled_X と q12_sampled_y の対応関係が保たれていません。 / The correspondence between q12_sampled_X and q12_sampled_y is not maintained.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.all(q12_sampled_X == np.array([[7, 8, 9], [10, 11, 12], [1, 2, 3], [7, 8, 9], [7, 8, 9]]))\n'
                                               '>>> assert np.all(q12_sampled_y == np.array([3, 4, 1, 3, 3]))\n',
                                       'failure_message': 'q12_sampled_X と q12_sampled_y の値が誤っています。復元抽出をおこなっていますか？np.random.seed(42)は最初に実行されていますか？ / The values of q12_sampled_X and q12_sampled_y are '
                                                          'incorrect. Are you performing resampling? Has np.random.seed(42) been run first?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
