OK_FORMAT = True

test = {   'name': 'Exercise 2-1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert q21_best_n_estimators == 100\n',
                                       'failure_message': 'q21_best_n_estimators の値が誤っています。random_state=42 で fit していますか？ / The value of q21_best_n_estimators is incorrect. Are you fitting with '
                                                          'random_state=42?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.isclose(q21_best_accuracy, 0.973651191969887, atol=1e-05)\n',
                                       'failure_message': 'q21_best_accuracy の値が誤っています。random_state=42 で fit していますか？ / The value of q21_best_accuracy is incorrect. Are you fitting with '
                                                          'random_state=42?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert len(q21_all_accuracies) == 9\n',
                                       'failure_message': '試行回数が足りていません。[1,2,4,10,20,40,100,200,400]の全ての要素に対して試行していますか？ / Not enough trials were performed. Have you tried all elements of '
                                                          '[1,2,4,10,20,40,100,200,400]?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert np.allclose(q21_all_accuracies, [0.7728983688833124, 0.7540777917189461, 0.8782936010037641, 0.946047678795483, 0.9598494353826851, '
                                               '0.9711417816813049, 0.973651191969887, 0.9698870765370138, 0.972396486825596], atol=1e-05)\n',
                                       'failure_message': 'q21_all_accuracies の値が誤っています。random_state=42 で fit していますか？ / The values of q21_all_accuracies are incorrect. Are you fitting with '
                                                          'random_state=42?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
