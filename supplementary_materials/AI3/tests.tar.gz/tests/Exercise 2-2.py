OK_FORMAT = True

test = {   'name': 'Exercise 2-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q22_trigonometric_features(np.array([1, 2])), np.ndarray)\n',
                                       'failure_message': '返り値が np.array になっていません。 / The return value is not a NumPy array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_array_almost_equal(q22_trigonometric_features(np.array([1])), np.array([[1, 0.84, 0.54]]), decimal=2)\n',
                                       'failure_message': 'np.array([1]) を与えたときの返り値が誤っています。x, sin x, cos x の順番になっていますか？ / The return value for np.array([1]) is incorrect. Is the order x, sin x, cos '
                                                          'x?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_array_almost_equal(q22_trigonometric_features(np.array([1, 2, 3])), np.array([[1, 0.84, 0.54], [2, 0.91, -0.42], [3, 0.14, '
                                               '-0.99]]), decimal=2)\n',
                                       'failure_message': 'np.array([1, 2, 3]) を与えたときの返り値が誤っています。 / The return value for np.array([1, 2, 3]) is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_array_almost_equal(q22_trigonometric_features(np.array([1, 2.5, 3])), np.array([[1, 0.84, 0.54], [2.5, 0.6, -0.8], [3, 0.14, '
                                               '-0.99]]), decimal=2)\n',
                                       'failure_message': 'np.array([1, 2.5, 3]) を与えたときの返り値が誤っています。 / The return value for np.array([1, 2.5, 3]) is incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_array_almost_equal(q22_trigonometric_features(np.array([-1, 2, -3])), np.array([[-1, -0.84, 0.54], [2, 0.91, -0.42], [-3, -0.14, '
                                               '-0.99]]), decimal=2)\n',
                                       'failure_message': 'np.array([-1, 2, -3]) を与えたときの返り値が誤っています。 / The return value for np.array([-1, 2, -3]) is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
