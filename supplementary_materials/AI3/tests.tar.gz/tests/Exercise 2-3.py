OK_FORMAT = True

test = {   'name': 'Exercise 2-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> from sklearn.utils.validation import check_is_fitted\n>>> check_is_fitted(q23_lr)\n',
                                       'failure_message': 'q23_lr.fit(X,y) が行われていません。学習（回帰モデルの構築）のために fit を行ってください。 / q23_lr.fit(X,y) was not performed. Please perform fit to build the regression '
                                                          'model.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.testing.assert_equal(len(q23_lr.coef_), 3)\n',
                                       'failure_message': 'q23_lr.coef_ が3つの要素からなる配列になっていません。各点はq22_trigonometric_featuresで3つの値で表現されるため、coef_も3つの要素からなる配列になるはずです。 / q23_lr.coef_ does not have 3 '
                                                          'elements. Each point is represented by 3 values in q22_trigonometric_features, so coef_ should also be a 3-element array.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n>>> np.testing.assert_array_almost_equal(q23_lr.coef_, [0.0, 0.0, 1.0])\n',
                                       'failure_message': 'q23_lr.coef_ が適切な値になっていません。fitに与えるデータを間違えていませんか？ / q23_lr.coef_ has incorrect values. Are you providing the correct data to fit?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n>>> np.testing.assert_almost_equal(q23_lr.intercept_, 0.0)\n',
                                       'failure_message': 'q23_lr.intercept_ が適切な値になっていません。fitに与えるデータを間違えていませんか？ / q23_lr.intercept_ has incorrect values. Are you providing the correct data to fit?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
