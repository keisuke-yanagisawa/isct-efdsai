OK_FORMAT = True

test = {   'name': 'Exercise 1-2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> from sklearn.utils.validation import check_is_fitted\n>>> check_is_fitted(q12_lr)\n',
                                       'failure_message': 'q12_lr.fit(X,y) が行われていません。学習（回帰モデルの構築）のために fit を行ってください。 / q12_lr.fit(X,y) was not performed. Please perform fit to build the regression '
                                                          'model.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n>>> np.testing.assert_array_almost_equal(q12_lr.coef_, [1.0, 1.0])\n',
                                       'failure_message': 'q12_lr.coef_ が適切な値になっていません。fitに与えるデータを間違えていませんか？ / q12_lr.coef_ has incorrect values. Are you providing the correct data to fit?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> import numpy as np\n>>> np.testing.assert_almost_equal(q12_lr.intercept_, 1.0)\n',
                                       'failure_message': 'q12_lr.intercept_ が適切な値になっていません。fitに与えるデータを間違えていませんか？ / q12_lr.intercept_ has incorrect values. Are you providing the correct data to fit?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
