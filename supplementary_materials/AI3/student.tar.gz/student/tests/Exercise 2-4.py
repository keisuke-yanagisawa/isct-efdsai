OK_FORMAT = True

test = {   'name': 'Exercise 2-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> __expected_rmse = 0.0\n>>> np.allclose(q24_rmse, __expected_rmse)\nTrue',
                                       'failure_message': 'RMSE値が適切な値になっていません。predictに与えるデータが誤っている、あるいはRMSEの計算方法が誤っている可能性があります。 / The RMSE value is incorrect. You may have provided the wrong data to '
                                                          'predict or used an incorrect method for RMSE calculation.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
