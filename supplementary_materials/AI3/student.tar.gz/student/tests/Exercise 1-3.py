OK_FORMAT = True

test = {   'name': 'Exercise 1-3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> q13_ridge_1.get_params()['alpha'] == 1\nTrue",
                                       'failure_message': 'q13_ridge_1 において、alpha が適切に設定されていません。Ridgeモデル構築の際に、alpha=1を指定してください。 / alpha is not correctly set for q13_ridge_1. Specify alpha=1 when '
                                                          'building the Ridge model.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> from sklearn.linear_model import Ridge\n'
                                               '>>> _ans_q13_ridge_1 = Ridge(alpha=1).fit(q11_X, q11_y)\n'
                                               '>>> np.allclose(q13_ridge_1.coef_, _ans_q13_ridge_1.coef_) and np.allclose(q13_ridge_1.intercept_, _ans_q13_ridge_1.intercept_)\n'
                                               'True',
                                       'failure_message': 'q13_ridge_1 において、q13_ridge_1.coef_あるいはq13_ridge_1.intercept_ が誤っています。fitに与えるデータを間違えていませんか？ / q13_ridge_1.coef_ or q13_ridge_1.intercept_ '
                                                          'has incorrect values. Are you providing the correct data to fit?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> q13_ridge_10.get_params()['alpha'] == 10\nTrue",
                                       'failure_message': 'q13_ridge_10 において、alpha が適切に設定されていません。Ridgeモデル構築の際に、alpha=10を指定してください。 / alpha is not correctly set for q13_ridge_10. Specify alpha=10 when '
                                                          'building the Ridge model.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> from sklearn.linear_model import Ridge\n'
                                               '>>> _ans_q13_ridge_10 = Ridge(alpha=10).fit(q11_X, q11_y)\n'
                                               '>>> np.allclose(q13_ridge_10.coef_, _ans_q13_ridge_10.coef_) and np.allclose(q13_ridge_10.intercept_, _ans_q13_ridge_10.intercept_)\n'
                                               'True',
                                       'failure_message': 'q13_ridge_10 において、q13_ridge_10.coef_あるいはq13_ridge_10.intercept_ が誤っています。fitに与えるデータを間違えていませんか？ / q13_ridge_10.coef_ or '
                                                          'q13_ridge_10.intercept_ has incorrect values. Are you providing the correct data to fit?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
