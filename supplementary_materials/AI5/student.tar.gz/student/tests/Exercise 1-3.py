OK_FORMAT = True

test = {   'name': 'Exercise 1-3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> q13_slp[0].in_features\n3', 'failure_message': '入力が3次元になっているべきです / The input should be 3-dimensional', 'hidden': False, 'locked': False},
                                   {'code': '>>> q13_slp[0].out_features\n1', 'failure_message': '出力が1次元になっているべきです / The output should be one-dimensional', 'hidden': False, 'locked': False},
                                   {   'code': '>>> import torch.nn as nn\n>>> not isinstance(q13_slp[-1], nn.Sigmoid)\nTrue',
                                       'failure_message': "最終層のSigmoidがFalseであることを確認して下さい / Ensure that the final layer's Sigmoid is False",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
