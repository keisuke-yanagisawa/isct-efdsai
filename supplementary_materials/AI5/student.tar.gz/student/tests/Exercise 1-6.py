OK_FORMAT = True

test = {   'name': 'Exercise 1-6',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> print(q16_Y_pred[:5])\ntensor([[0.0045],\n        [0.0356],\n        [0.0307],\n        [0.2185],\n        [0.0069]], grad_fn=<SliceBackward0>)\n',
                                       'failure_message': 'q16_Y_pred の値が誤っています。最初の要素は 0.0045 となるはずです。 / The values of q16_Y_pred are incorrect. The first element should be 0.0045.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(q16_accuracy)\ntensor(0.9500)\n',
                                       'failure_message': 'tensor(0.9500)になっている必要があります。 / It should be tensor(0.9500).',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
