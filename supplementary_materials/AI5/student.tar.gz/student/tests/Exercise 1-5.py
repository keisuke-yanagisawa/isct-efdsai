OK_FORMAT = True

test = {   'name': 'Exercise 1-5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q15_Y_pred_vals, torch.Tensor)\n>>> q15_Y_pred_vals.shape\ntorch.Size([100, 1])',
                                       'failure_message': 'q15_Y_preds_valsは100行1列のtorch.Tensorであるべきです。 / q15_Y_pred_vals should be a 100 by 1 torch.Tensor.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(q15_Y_pred_vals[:5])\n'
                                               'tensor([[-5.4025],\n'
                                               '        [-3.2995],\n'
                                               '        [-3.4531],\n'
                                               '        [-1.2746],\n'
                                               '        [-4.9757]], grad_fn=<SliceBackward0>)\n',
                                       'failure_message': 'q15_Y_pred_vals の値が誤っています。最初の要素は -5.4025 となるはずです。 / The values of q15_Y_pred_vals are incorrect. The first element should be -5.4025.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
