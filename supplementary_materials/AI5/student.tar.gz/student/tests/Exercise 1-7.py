OK_FORMAT = True

test = {   'name': 'Exercise 1-7',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> q17_mlp\n'
                                               'Sequential(\n'
                                               '  (0): Linear(in_features=3, out_features=20, bias=True)\n'
                                               '  (1): Sigmoid()\n'
                                               '  (2): Linear(in_features=20, out_features=1, bias=True)\n'
                                               ')',
                                       'failure_message': 'q17_mlp が適切になっていません。2つのLinear層の間にSigmoidは入っていますか？ / q17_mlp is not correct. Is there a Sigmoid between the two Linear layers?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> isinstance(optimizer, torch.optim.SGD)\nTrue',
                                       'failure_message': 'optimizerとしてSGD以外が利用されています。 / Something other than SGD is being used as the optimizer.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> optimizer.param_groups[0]['lr'] == 0.1\nTrue",
                                       'failure_message': 'optimizerの学習率は 0.1 に設定してください。 / The learning rate of the optimizer should be set to 0.1.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> optimizer.param_groups[0]['params'][0] in q17_mlp.parameters()\nTrue",
                                       'failure_message': 'optimizerが更新するモデルが間違っています。optimizer = ...(SOMETHING, ...) の SOMETHING の部分を改めて確認してください。 / The model the optimizer updates is incorrect. '
                                                          'Please check the SOMETHING part of optimizer = ...(SOMETHING, ...).',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(loss_fn)\nBCEWithLogitsLoss()\n',
                                       'failure_message': '損失関数はBCEWithLogitsLoss()になっている必要があります / The loss function should be BCEWithLogitsLoss()',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert not torch.allclose(q17_mlp_copy.state_dict()['0.weight'], q17_mlp.state_dict()['0.weight'])\n"
                                               ">>> assert not torch.allclose(q17_mlp_copy.state_dict()['0.bias'], q17_mlp.state_dict()['0.bias'])\n"
                                               ">>> assert not torch.allclose(q17_mlp_copy.state_dict()['2.weight'], q17_mlp.state_dict()['2.weight'])\n"
                                               ">>> assert not torch.allclose(q17_mlp_copy.state_dict()['2.bias'], q17_mlp.state_dict()['2.bias'])\n",
                                       'failure_message': 'q17_mlp の重みパラメータが更新されていません。 / The weight parameters of q17_mlp have not been updated.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
