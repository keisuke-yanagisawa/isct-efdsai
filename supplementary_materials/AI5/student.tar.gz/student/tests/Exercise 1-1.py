OK_FORMAT = True

test = {   'name': 'Exercise 1-1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(q11_X_torch) == torch.Tensor\nTrue', 'failure_message': 'torch.Tensorである必要があります。 / It must be a torch.Tensor.', 'hidden': False, 'locked': False},
                                   {'code': '>>> q11_X_torch.dtype == torch.float32\nTrue', 'failure_message': 'torch.float32であるべきです / It should be torch.float32', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(q11_Y_torch) == torch.Tensor\nTrue', 'failure_message': 'torch.Tensorである必要があります。 / It must be a torch.Tensor.', 'hidden': False, 'locked': False},
                                   {'code': '>>> q11_Y_torch.dtype == torch.float32\nTrue', 'failure_message': 'torch.float32であるべきです / It should be torch.float32', 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert isinstance(q11_Y_torch, torch.Tensor)\n>>> q11_Y_torch.shape\ntorch.Size([100, 1])',
                                       'failure_message': 'q11_Y_torchhs100行1列であるべきです。 / q11_Y_torch should be N by 1.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
