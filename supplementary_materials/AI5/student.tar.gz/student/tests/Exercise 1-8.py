OK_FORMAT = True

test = {   'name': 'Exercise 1-8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> q18_Y_pred.shape\ntorch.Size([100, 1])', 'failure_message': '100行1列である必要があります。 / It should be 100 by 1.', 'hidden': False, 'locked': False},
                                   {   'code': '>>> q18_Y_pred[:5]\ntensor([[0.0005],\n        [0.0046],\n        [0.0042],\n        [0.1200],\n        [0.0007]], grad_fn=<SliceBackward0>)',
                                       'failure_message': 'q_18_Y_pred の値が誤っています。最初の要素は 0.0005 になるはずです。 / The values of q18_Y_pred are incorrect. The first element should be 0.0005.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> np.allclose(q18_accuracy, 0.96)\nTrue', 'failure_message': '0.96になっている必要があります。 / It should be 0.96.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
