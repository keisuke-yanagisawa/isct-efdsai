OK_FORMAT = True

test = {   'name': 'Exercise 1-8',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> torch.testing.assert_close(q18_Y_pred.shape, torch.Size([100, 1]))\n',
                                       'failure_message': '100行1列である必要があります。 / It should be 100 by 1.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> ans_mlp = copy.deepcopy(q17_mlp_copy)\n'
                                               '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_mlp.parameters(), lr=0.1)\n'
                                               '>>> ans_loss_fn = torch.nn.BCEWithLogitsLoss()\n'
                                               '>>> n_epochs = 100\n'
                                               '>>> for _ in range(n_epochs):\n'
                                               '...     for X, Y in q12_dataloader:\n'
                                               '...         Y_pred_val = ans_mlp(X)\n'
                                               '...         loss = ans_loss_fn(Y_pred_val, Y)\n'
                                               '...         ans_optimizer.zero_grad()\n'
                                               '...         loss.backward()\n'
                                               '...         ans_optimizer.step()\n'
                                               '>>> ans_Y_pred = torch.sigmoid(ans_mlp(q15_X_torch))\n'
                                               '>>> torch.testing.assert_close(q18_Y_pred, ans_Y_pred)\n',
                                       'failure_message': 'q_18_Y_pred の値が誤っています。 / The values of q18_Y_pred are incorrect.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> ans_mlp = copy.deepcopy(q17_mlp_copy)\n'
                                               '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_mlp.parameters(), lr=0.1)\n'
                                               '>>> ans_loss_fn = torch.nn.BCEWithLogitsLoss()\n'
                                               '>>> n_epochs = 100\n'
                                               '>>> for _ in range(n_epochs):\n'
                                               '...     for X, Y in q12_dataloader:\n'
                                               '...         Y_pred_val = ans_mlp(X)\n'
                                               '...         loss = ans_loss_fn(Y_pred_val, Y)\n'
                                               '...         ans_optimizer.zero_grad()\n'
                                               '...         loss.backward()\n'
                                               '...         ans_optimizer.step()\n'
                                               '>>> ans_Y_pred = torch.sigmoid(ans_mlp(q15_X_torch))\n'
                                               '>>> ans_accuracy = torch.mean(((ans_Y_pred > 0.5) == q15_Y_torch).float())\n'
                                               '>>> np.testing.assert_almost_equal(q18_accuracy, ans_accuracy)\n',
                                       'failure_message': '正解率が誤っています。 / The accuracy is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
