OK_FORMAT = True

test = {   'name': 'Exercise 1-5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(q15_Y_pred_vals, torch.Tensor)\n>>> torch.testing.assert_close(q15_Y_pred_vals.shape, torch.Size([100, 1]))\n',
                                       'failure_message': 'q15_Y_preds_valsは100行1列のtorch.Tensorであるべきです。 / q15_Y_pred_vals should be a 100 by 1 torch.Tensor.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_slp = copy.deepcopy(q13_slp_initial)\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_slp.parameters(), lr=0.1)\n'
                                               '>>> ans_loss_fn = torch.nn.BCEWithLogitsLoss()\n'
                                               '>>> for _ in range(100):\n'
                                               '...     for X, Y in q12_dataloader:\n'
                                               '...         Y_pred_val = ans_slp(X)\n'
                                               '...         loss = ans_loss_fn(Y_pred_val, Y)\n'
                                               '...         ans_optimizer.zero_grad()\n'
                                               '...         loss.backward()\n'
                                               '...         ans_optimizer.step()\n'
                                               '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_test_Y_pred_vals = ans_slp(q15_X_torch)\n'
                                               '>>> torch.testing.assert_close(q15_Y_pred_vals, ans_test_Y_pred_vals)\n',
                                       'failure_message': 'q15_Y_pred_vals の値が誤っています。学習率は正しく 0.1 に設定されていますか？ / The values of q15_Y_pred_vals are incorrect. Is the learning rate correctly set to 0.1?',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
