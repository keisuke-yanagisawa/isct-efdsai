OK_FORMAT = True

test = {   'name': 'Exercise 1-6',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_slp = copy.deepcopy(q13_slp_initial)\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_slp.parameters(), lr=0.1)\n'
                                               '>>> ans_loss_fn = torch.nn.BCEWithLogitsLoss()\n'
                                               '>>> for _ in range(100):\n'
                                               '...     for X, Y in q12_dataloader:\n'
                                               '...         Y_pred_val = ans_slp(X)\n'
                                               '...         loss = ans_loss_fn(Y_pred_val, Y)\n'
                                               '...         ans_optimizer.zero_grad()\n'
                                               '...         loss.backward()\n'
                                               '...         ans_optimizer.step()\n'
                                               '>>> ans_test_Y_pred_vals = ans_slp(q15_X_torch)\n'
                                               '>>> ans_test_Y_pred = torch.sigmoid(ans_test_Y_pred_vals)\n'
                                               '>>> torch.testing.assert_close(q16_Y_pred, ans_test_Y_pred)\n',
                                       'failure_message': 'q16_Y_pred の値が誤っています。シグモイド関数は利用しましたか？ / The values of q16_Y_pred are incorrect. Did you use the sigmoid function?',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> _ = torch.manual_seed(42)\n'
                                               '>>> ans_slp = copy.deepcopy(q13_slp_initial)\n'
                                               '>>> ans_optimizer = torch.optim.SGD(ans_slp.parameters(), lr=0.1)\n'
                                               '>>> ans_loss_fn = torch.nn.BCEWithLogitsLoss()\n'
                                               '>>> for _ in range(100):\n'
                                               '...     for X, Y in q12_dataloader:\n'
                                               '...         Y_pred_val = ans_slp(X)\n'
                                               '...         loss = ans_loss_fn(Y_pred_val, Y)\n'
                                               '...         ans_optimizer.zero_grad()\n'
                                               '...         loss.backward()\n'
                                               '...         ans_optimizer.step()\n'
                                               '>>> ans_test_Y_pred_vals = ans_slp(q15_X_torch)\n'
                                               '>>> ans_test_Y_pred = torch.sigmoid(ans_test_Y_pred_vals)\n'
                                               '>>> ans_accuracy = torch.mean(((ans_test_Y_pred > 0.5) == q15_Y_torch).float())\n'
                                               '>>> np.testing.assert_almost_equal(q16_accuracy.item(), ans_accuracy.item())\n',
                                       'failure_message': '正解率が誤っています。 / The accuracy is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
