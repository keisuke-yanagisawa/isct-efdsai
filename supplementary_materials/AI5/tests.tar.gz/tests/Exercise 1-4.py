OK_FORMAT = True

test = {   'name': 'Exercise 1-4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(optimizer, torch.optim.SGD)\n',
                                       'failure_message': 'optimizerがtorch.optim.SGDである必要があります / The optimizer must be torch.optim.SGD',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> np.testing.assert_almost_equal(optimizer.param_groups[0]['lr'], 0.1)\n",
                                       'failure_message': '学習率("lr")が0.1である必要があります。 / The learning rate ("lr") should be 0.1.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> assert not torch.allclose(q13_slp.state_dict()['0.weight'], q13_slp_initial.state_dict()['0.weight'])\n"
                                               ">>> assert not torch.allclose(q13_slp.state_dict()['0.bias'], q13_slp_initial.state_dict()['0.bias'])\n",
                                       'failure_message': '訓練前(q13_slp_copy)と重みパラメータ(バイアスも)が変わっている必要があります。 / The weight parameters (including the bias) should have changed.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
