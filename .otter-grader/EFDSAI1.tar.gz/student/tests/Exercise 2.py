OK_FORMAT = True

test = {   'name': 'Exercise 2',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> f'{dist_q2:.3f}'\n'5.000'", 'failure_message': '距離 dist_q2 が誤っています。 / Distance dist_q2 is incorrect.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
