OK_FORMAT = True

test = {   'name': 'Exercise 8',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> lst2 = [5, 3, 2, 5, 7, 10, 10, 5, 0, 9, 3, 1, 6, 6, 0]\n>>> print(median(lst2))\n5\n',
                                       'failure_message': '配列をソートすると、中央値が計算しやすくなります。 / Sorting the array makes it easier to compute the median.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
