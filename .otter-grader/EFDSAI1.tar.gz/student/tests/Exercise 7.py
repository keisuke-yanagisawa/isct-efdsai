OK_FORMAT = True

test = {   'name': 'Exercise 7',
    'points': None,
    'suites': [   {   'cases': [   {   'code': ">>> lst1 = [8, 2, 4, 0, 5, 6, 0, 5, 6, 3]\n>>> print(f'{var(lst1):.3f}')\n6.290\n",
                                       'failure_message': '計算された分散の値が誤っています。正しくは約6.29になるはずです。 / The computed variance value is incorrect.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
