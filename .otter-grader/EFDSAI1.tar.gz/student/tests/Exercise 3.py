OK_FORMAT = True

test = {   'name': 'Exercise 3',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> f'{dist_q3:.3f}'\n'3.606'", 'failure_message': '距離 dist_q3 が誤っています。 / Distance dist_q2 is incorrect.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
