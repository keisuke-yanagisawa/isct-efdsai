OK_FORMAT = True

test = {   'name': 'Exercise 9',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> func_q9(N, A, B)\n84', 'failure_message': '計算された合計値が誤っています。 / The computed sum value is incorrect.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
