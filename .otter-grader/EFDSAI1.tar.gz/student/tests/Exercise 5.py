OK_FORMAT = True

test = {   'name': 'Exercise 5',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> f'{dist_q5:.3f}'\n'17.000'", 'failure_message': '距離 dist_q5 が誤っています。 / Distance dist_q2 is incorrect.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
