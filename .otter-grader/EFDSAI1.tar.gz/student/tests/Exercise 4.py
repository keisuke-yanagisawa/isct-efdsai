OK_FORMAT = True

test = {   'name': 'Exercise 4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> random.seed(0)\n>>> rand_int == random.randint(0, 50)\nTrue',
                                       'failure_message': 'random.seed(0) はそのままとしてください。 / Please keep random.seed(0) as is.',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> result\n'EVEN'", 'failure_message': 'If 文の条件が適切に設定されていません。 / The if statement condition is not set correctly.', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
