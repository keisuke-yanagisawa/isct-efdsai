OK_FORMAT = True

test = {   'name': 'Exercise 4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> random.seed(0)\n>>> rand_int == random.randint(0, 50)\nTrue',
                                       'failure_message': 'random.seed(0) はそのままとしてください。 / Please keep random.seed(0) as is.',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> random.seed(0)\n>>> tmp_q4 = 'ODD' if random.randint(0, 50) % 2 == 1 else 'EVEN'\n>>> result == tmp_q4\nTrue",
                                       'failure_message': 'If 文の条件が適切に設定されていません。 / The if statement condition is not set correctly.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
